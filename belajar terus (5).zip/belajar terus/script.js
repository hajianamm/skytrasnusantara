window.addEventListener("load", function () {
  const loading = document.getElementById("loading");
  loading.style.display = "none";
});

const slides = document.querySelector(".slides");
const images = document.querySelectorAll(".slides img");
const prevBtn = document.querySelector(".prev");
const nextBtn = document.querySelector(".next");
const dotsContainer = document.querySelector(".dots");

let index = 0;
const total = images.length;

// Buat dot navigasi
images.forEach((_, i) => {
  const dot = document.createElement("span");
  dot.classList.add("dot");
  if (i === 0) dot.classList.add("active");
  dot.addEventListener("click", () => goToSlide(i));
  dotsContainer.appendChild(dot);
});

function updateSlider() {
  slides.style.transform = `translateX(-${index * 100}%)`;
  document.querySelectorAll(".dot").forEach(dot => dot.classList.remove("active"));
  document.querySelectorAll(".dot")[index].classList.add("active");
}

function goToSlide(i) {
  index = i;
  updateSlider();
}

prevBtn.addEventListener("click", () => {
  index = (index - 1 + total) % total;
  updateSlider();
});

nextBtn.addEventListener("click", () => {
  index = (index + 1) % total;
  updateSlider();
});

// Auto slide
setInterval(() => {
  index = (index + 1) % total;
  updateSlider();
}, 12000);
